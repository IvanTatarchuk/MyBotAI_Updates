import subprocess
import os
import sys
import platform
import glob

def run_command(command, cwd=None, shell=True):
    """
    Виконує команду в командному рядку і виводить результат.
    """
    print(f"\n>>> Виконую команду: {command}")
    try:
        # shell=True потрібен для команд типу 'venv\Scripts\activate' на Windows
        result = subprocess.run(command, cwd=cwd, shell=shell, capture_output=True, text=True, check=True, encoding='cp866')
        print("Стандартний вивід:\n", result.stdout)
        if result.stderr:
            print("Вивід помилок (stderr):\n", result.stderr)
        return True
    except subprocess.CalledProcessError as e:
        print(f"ПОМИЛКА ВИКОНАННЯ КОМАНДИ '{command}':")
        print("Стандартний вивід (stdout):\n", e.stdout)
        print("Вивід помилок (stderr):\n", e.stderr)
        print(f"Код виходу: {e.returncode}")
        return False
    except Exception as e:
        print(f"Непередбачена помилка: {e}")
        return False

def setup_bot_environment():
    current_dir = os.getcwd()
    venv_dir = os.path.join(current_dir, "venv")
    scripts_dir = os.path.join(venv_dir, "Scripts") if platform.system() == "Windows" else os.path.join(venv_dir, "bin")
    python_executable = os.path.join(scripts_dir, "python.exe") if platform.system() == "Windows" else os.path.join(scripts_dir, "python")

    print("Починаю автоматичне налаштування середовища бота...")

    # 1. Видалення старого віртуального середовища (якщо існує)
    if os.path.exists(venv_dir):
        print(f"Видаляю існуюче віртуальне середовище: {venv_dir}")
        if not run_command(f"rmdir /s /q {venv_dir}" if platform.system() == "Windows" else f"rm -rf {venv_dir}"):
            print("Не вдалося видалити старе віртуальне середовище. Будь ласка, видаліть вручну і спробуйте знову.")
            return

    # 2. Створення нового віртуального середовища
    print("Створюю нове віртуальне середовище...")
    if not run_command(f"{sys.executable} -m venv venv"):
        print("Не вдалося створити нове віртуальне середовище. Перевірте встановлення Python та PATH.")
        return

    # 3. Активація віртуального середовища
    # Напряму активувати venv.Scripts\activate з іншого скрипта subprocess складно
    # Замість цього, ми будемо запускати pip та python використовуючи повний шлях до venv

    print("Віртуальне середовище створено. Продовжую встановлення пакетів...")

    # 4. Встановлення PyAudio з WHL-файлу (якщо знайдено)
    pyaudio_whl = None
    # Шукаємо будь-який whl файл pyaudio в поточній директорії
    whl_files = glob.glob(os.path.join(current_dir, "PyAudio-*.whl"))
    if whl_files:
        pyaudio_whl = whl_files[0] # Беремо перший знайдений
        print(f"Знайдено файл PyAudio WHL: {pyaudio_whl}")
        if not run_command(f"{python_executable} -m pip install {pyaudio_whl}"):
            print("ПОПЕРЕДЖЕННЯ: Не вдалося встановити PyAudio з WHL-файлу. Бот може не працювати з розпізнаванням мови.")
            # Не виходимо, бо інші пакети можуть бути встановлені
    else:
        print("Файл PyAudio WHL не знайдено в поточній директорії. Спробую встановити через pip.")
        if not run_command(f"{python_executable} -m pip install pyaudio"):
             print("ПОПЕРЕДЖЕННЯ: Не вдалося встановити PyAudio через pip. Бот може не працювати з розпізнаванням мови.")

    # 5. Встановлення всіх необхідних бібліотек з requirements.txt
    requirements_path = os.path.join(current_dir, "requirements.txt")
    if os.path.exists(requirements_path):
        print(f"Встановлюю пакети з {requirements_path}...")
        if not run_command(f"{python_executable} -m pip install -r {requirements_path}"):
            print("ПОМИЛКА: Не вдалося встановити всі пакети з requirements.txt. Перевірте вивід помилок.")
            return
    else:
        print("Файл requirements.txt не знайдено. Будь ласка, створіть його.")
        return

    print("\nНалаштування середовища бота завершено!")
    print("Тепер ви можете запустити бота командою: venv\\Scripts\\python main.py (або venv\\Scripts\\activate, а потім python main.py)")

if __name__ == "__main__":
    setup_bot_environment()