import webbrowser
import os
import wikipedia
import pyautogui
import time
import requests
import json
import psutil
import shutil
import hashlib # Dodany do weryfikacji aktualizacji
import ast # Dodany do bezpiecznych obliczeń

# --- KLUCZ API GEMINI ---
# KLUCZ API POWINIEN BYĆ USTAWIONY JAKO ZMIENNA ŚRODOWISKOWA!
# NIE WPISUJ GO TUTAJ BEZPOŚREDNIO W KODZIE W WERSJI PRODUKCYJNEJ!
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY") 
# --- KONIEC KLUCZA API ---

def open_website(url):
    """Otwiera stronę internetową w domyślnej przeglądarce."""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    webbrowser.open(url)
    return f"Otwieram {url}"

def open_program(program_name):
    """Próbuje otworzyć program po nazwie (Windows)."""
    try:
        os.startfile(program_name)
        return f"Otwieram {program_name}."
    except Exception as e:
        return f"Nie udało się otworzyć programu {program_name}. Błąd: {e}"

def search_wikipedia(query):
    """Szuka informacji w Wikipedii."""
    try:
        wikipedia.set_lang("pl")
        results = wikipedia.summary(query, sentences=2)
        return f"Według Wikipedii: {results}"
    except wikipedia.exceptions.PageError:
        return f"Nie mogę znaleźć informacji o {query} w Wikipedii."
    except wikipedia.exceptions.DisambiguationError as e:
        return f"Zapytanie {query} jest niejednoznaczne. Proszę sprecyzować. Możliwe opcje: {', '.join(e.options[:5])}"
    except Exception as e:
        return f"Wystąpił błąd podczas wyszukiwania w Wikipedii: {e}"

def type_text(text_to_type):
    """Wpisuje podany tekst za pomocą pyautogui."""
    pyautogui.write(text_to_type)
    return f"Wpisuję tekst: '{text_to_type}'"

def press_key(key_name):
    """Naciska klawisz za pomocą pyautogui."""
    try:
        pyautogui.press(key_name)
        return f"Naciskam klawisz: {key_name}"
    except Exception as e:
        return f"Nie udało się nacisnąć klawisza {key_name}. Błąd: {e}"

def send_hotkey(key1, key2):
    """Naciska kombinację klawiszy (skrót klawiszowy) za pomocą pyautogui."""
    try:
        pyautogui.hotkey(key1, key2)
        return f"Naciskam klawisze skrótu: {key1} + {key2}"
    except Exception as e:
        return f"Nie udało się nacisnąć klawiszy skrótu {key1} + {key2}. Błąd: {e}"

def shutdown_computer():
    """Wyłącza komputer (Windows)."""
    os.system("shutdown /s /t 1 /f")
    return "Wyłączam komputer. Do zobaczenia!"

def restart_computer():
    """Ponownie uruchamia komputer (Windows)."""
    os.system("shutdown /r /t 1 /f")
    return "Ponownie uruchamiam komputer."

def create_folder(folder_name):
    """Tworzy nowy folder w bieżącym katalogu roboczym."""
    try:
        os.makedirs(folder_name)
        return f"Utworzono folder: {folder_name}"
    except FileExistsError:
        return f"Folder '{folder_name}' już istnieje."
    except Exception as e:
        return f"Nie udało się utworzyć folderu '{folder_name}'. Błąd: {e}"

def delete_folder(folder_name):
    """Usuwa folder (i jego zawartość) w bieżącym katalogu roboczym."""
    try:
        shutil.rmtree(folder_name)
        return f"Usunięto folder: {folder_name}"
    except FileNotFoundError:
        return f"Folder '{folder_name}' nie istnieje."
    except Exception as e:
        return f"Nie udało się usunąć folderu '{folder_name}'. Błąd: {e}"

def open_special_folder(folder_type):
    """Otwiera specjalne foldery systemowe (np. Pulpit, Dokumenty)."""
    special_folders = {
        "pulpit": os.path.join(os.path.expanduser("~"), "Desktop"),
        "dokumenty": os.path.join(os.path.expanduser("~"), "Documents"),
        "pobrane": os.path.join(os.path.expanduser("~"), "Downloads"),
        "muzyka": os.path.join(os.path.expanduser("~"), "Music"),
        "obrazy": os.path.join(os.path.expanduser("~"), "Pictures"),
        "wideo": os.path.join(os.path.expanduser("~"), "Videos"),
    }
    path = special_folders.get(folder_type.lower())
    if path and os.path.exists(path):
        os.startfile(path)
        return f"Otwieram folder: {folder_type}"
    else:
        return f"Nie znam folderu '{folder_type}' lub nie mogę go otworzyć."

def get_disk_space():
    """Zwraca informacje o wolnym miejscu na dysku C:."""
    try:
        disk_usage = psutil.disk_usage('C:\\')
        total_gb = disk_usage.total / (1024**3)
        used_gb = disk_usage.used / (1024**3)
        free_gb = disk_usage.free / (1024**3)
        percent_used = disk_usage.percent
        return (f"Dysk C: ma {total_gb:.2f} GB pojemności. "
                f"Wykorzystano {used_gb:.2f} GB ({percent_used:.1f}%). "
                f"Wolne miejsce: {free_gb:.2f} GB.")
    except Exception as e:
        return f"Nie udało się pobrać informacji o dysku. Błąd: {e}"

def calculate_expression(expression):
    """Wykonuje bezpieczne obliczenia matematyczne."""
    try:
        # Zastąp polskie słowa operatorami matematycznymi
        expression = expression.replace("plus", "+")
        expression = expression.replace("minus", "-")
        expression = expression.replace("razy", "*")
        expression = expression.replace("podzielić przez", "/")
        expression = expression.replace("podzielone przez", "/")
        
        # Usunięcie spacji dla łatwiejszego parsowania
        cleaned_expression = "".join(char for char in expression if char.isalnum() or char in "+-*/.")

        # Sprawdzanie, czy wyrażenie zawiera tylko dozwolone znaki
        allowed_chars = "0123456789.+-*/"
        if not all(c in allowed_chars for c in cleaned_expression):
            return "Błąd: Wyrażenie zawiera niedozwolone znaki. Proszę używać tylko cyfr i operatorów (+, -, *, /)."

        # Sprawdzenie, czy wyrażenie jest puste po czyszczeniu
        if not cleaned_expression:
            return "Błąd: Podano puste wyrażenie do obliczenia."
            
        # Wykonanie ewaluacji w bezpiecznym kontekście
        result = eval(cleaned_expression, {}, {}) # Puste globalne i lokalne
        return f"Wynik to: {result}"
    except (SyntaxError, TypeError, NameError):
        return "Nie mogę wykonać tego obliczenia. Sprawdź składnię."
    except ZeroDivisionError:
        return "Nie można dzielić przez zero!"
    except Exception as e:
        return f"Wystąpił błąd podczas obliczeń: {e}"

def simulate_game_action(action):
    """Symuluje akcje w grze za pomocą pyautogui."""
    if action == "skok":
        pyautogui.press('space')
        return "Wykonuję skok."
    elif action == "do przodu":
        pyautogui.keyDown('w')
        time.sleep(0.5)
        pyautogui.keyUp('w')
        return "Ruszam do przodu."
    elif action == "strzel":
        pyautogui.click()
        return "Strzelam."
    elif action == "przeładuj":
        pyautogui.press('r')
        return "Przeładowuję broń."
    return f"Nieznana akcja w grze: {action}"

def get_gemini_response(prompt_text):
    """
    Wysyła zapytanie do modelu Gemini i zwraca odpowiedź tekstową.
    """
    if not GEMINI_API_KEY:
        print("BŁĄD: Klucz API Gemini nie został ustawiony jako zmienna środowiskowa 'GEMINI_API_KEY'.")
        return "Przepraszam, nie mam jeszcze skonfigurowanego dostępu do sztucznej inteligencji (brak klucza API)."

    api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    payload = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"text": prompt_text}
                ]
            }
        ]
    }
    
    try:
        response = requests.post(api_url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        
        json_response = response.json()
        
        if json_response and "candidates" in json_response and len(json_response["candidates"]) > 0:
            first_candidate = json_response["candidates"][0]
            if "content" in first_candidate and "parts" in first_candidate["content"] and len(first_candidate["content"]["parts"]) > 0:
                return first_candidate["content"]["parts"][0]["text"]
        
        return "Nie udało mi się uzyskać sensownej odpowiedzi od sztucznej inteligencji."
        
    except requests.exceptions.RequestException as e:
        print(f"Błąd połączenia z Gemini API: {e}")
        return "Przepraszam, mam problem z połączeniem się ze sztuczną inteligencją."
    except Exception as e:
        print(f"Nieoczekiwany błąd podczas przetwarzania odpowiedzi Gemini: {e}")
        return "Wystąpił nieoczekiwany błąd."

def translate_text_with_gemini(text_to_translate, target_language="angielski"):
    """Tłumaczy tekst na podany język za pomocą Gemini."""
    prompt = f"Przetłumacz następujący tekst na język {target_language}: '{text_to_translate}'"
    return get_gemini_response(prompt)

def archive_folder(source_folder_path, output_archive_name, output_dir="."):
    """
    Archiwizuje (kompresuje) folder do pliku ZIP.
    source_folder_path: Ścieżka do folderu do archiwizacji.
    output_archive_name: Nazwa pliku archiwum (bez rozszerzenia .zip).
    output_dir: Katalog, w którym zostanie utworzone archiwum (domyślnie bieżący katalog).
    """
    try:
        # Sprawdź, czy folder źródłowy istnieje
        if not os.path.isdir(source_folder_path):
            return f"Błąd: Folder źródłowy '{source_folder_path}' nie istnieje."
        
        # Upewnij się, że katalog wyjściowy istnieje
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Tworzenie archiwum ZIP
        archive_path = shutil.make_archive(
            os.path.join(output_dir, output_archive_name), 
            'zip', 
            root_dir=source_folder_path
        )
        return f"Folder '{source_folder_path}' został zarchiwizowany do: {archive_path}"
    except Exception as e:
        return f"Wystąpił błąd podczas archiwizacji folderu: {e}"