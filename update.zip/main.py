import speech_recognition as sr
import pyttsx3
import time
import os
import sys
import subprocess
import random
import tkinter as tk
from tkinter import scrolledtext
import threading
import json # Dodany do ładowania pytań quizowych

from bot_commands import (
    open_website, open_program, search_wikipedia,
    type_text, press_key, send_hotkey,
    shutdown_computer, restart_computer, simulate_game_action,
    get_gemini_response,
    create_folder, delete_folder, open_special_folder, get_disk_space,
    calculate_expression,
    translate_text_with_gemini,
    archive_folder
)
from updater import check_for_updates, download_and_install_update, restart_bot

# --- KLASY DO ZARZĄDZANIA STANEM ---

class GameManager:
    def __init__(self):
        self.game_creation_mode_active = False
        self.guess_number_game_active = False
        self.secret_number = 0
        self.guess_attempts = 0
        self.quiz_active = False
        self.quiz_question_index = 0
        self.quiz_score = 0
        self.quiz_questions = [] # Zainicjuj pustą listę pytań

    def reset_guess_number_game(self):
        self.guess_number_game_active = False
        self.secret_number = 0
        self.guess_attempts = 0

    def reset_quiz_game(self):
        self.quiz_active = False
        self.quiz_question_index = 0
        self.quiz_score = 0
    
    def load_quiz_questions(self, filepath="quiz_questions.json"):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                self.quiz_questions = json.load(f)
            return True
        except FileNotFoundError:
            print(f"Błąd: Plik quizu '{filepath}' nie został znaleziony.")
            self.quiz_questions = []
            return False
        except json.JSONDecodeError as e:
            print(f"Błąd podczas parsowania pliku quizu '{filepath}': {e}")
            self.quiz_questions = []
            return False
        except Exception as e:
            print(f"Nieoczekiwany błąd podczas ładowania pytań quizu: {e}")
            self.quiz_questions = []
            return False

class BotAssistant:
    def __init__(self, output_widget, input_event_queue, input_event):
        self.game_manager = GameManager()
        self.last_generated_code = ""
        self.output_text_widget = output_widget
        self.gui_command_queue = input_event_queue
        self.gui_command_event = input_event
        
        # Inicjalizacja silnika TTS
        self.engine = pyttsx3.init()
        voices = self.engine.getProperty('voices')
        if not voices:
            print("Brak dostępnych głosów TTS w systemie! Proszę sprawdzić ustawienia mowy w Windows.")
        else:
            for voice in voices:
                if "polish" in voice.name.lower() or "pl-pl" in voice.id.lower():
                    self.engine.setProperty('voice', voice.id)
                    break
        
        # Inicjalizacja rozpoznawania mowy
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

    def speak(self, text):
        """Odzwierciedla tekst głosem i wyświetla w GUI."""
        if self.output_text_widget:
            self.output_text_widget.config(state='normal')
            self.output_text_widget.insert(tk.END, f"Bot: {text}\n")
            self.output_text_widget.see(tk.END)
            self.output_text_widget.config(state='disabled')
            root_window.update_idletasks()
        self.engine.say(text)
        self.engine.runAndWait()

    def get_gui_input_blocking(self):
        """Czeka na komendę z GUI (blokuje) i zwraca ją."""
        self.gui_command_event.clear()
        self.gui_command_event.wait()
        return self.gui_command_queue.pop(0)

    def listen_for_command(self):
        """Nasłuchuje komend głosowych i zwraca rozpoznany tekst."""
        with self.microphone as source:
            self.recognizer.adjust_for_ambient_noise(source)
            self.speak("Słucham...")
            self.output_text_widget.config(state='normal')
            self.output_text_widget.insert(tk.END, "Bot: Słucham...\n")
            self.output_text_widget.see(tk.END)
            self.output_text_widget.config(state='disabled')
            root_window.update_idletasks()

            try:
                audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=5)
            except sr.WaitTimeoutError:
                self.speak("Nie usłyszałem żadnej komendy.")
                return ""
            except Exception as e:
                self.speak(f"Błąd podczas nasłuchiwania: {e}")
                print(f"Błąd nasłuchiwania: {e}")
                return ""

        try:
            self.speak("Rozpoznaję...")
            self.output_text_widget.config(state='normal')
            self.output_text_widget.insert(tk.END, "Bot: Rozpoznaję...\n")
            self.output_text_widget.see(tk.END)
            self.output_text_widget.config(state='disabled')
            root_window.update_idletasks()

            command = self.recognizer.recognize_google(audio, language="pl-PL").lower()
            self.output_text_widget.config(state='normal')
            self.output_text_widget.insert(tk.END, f"Rozpoznano: {command}\n")
            self.output_text_widget.see(tk.END)
            self.output_text_widget.config(state='disabled')
            root_window.update_idletasks()

            print(f"Rozpoznano komendę: {command}")
            return command
        except sr.UnknownValueError:
            self.speak("Nie udało mi się rozpoznać mowy.")
            return ""
        except sr.RequestError as e:
            self.speak(f"Problem z usługą rozpoznawania mowy; {e}")
            print(f"Błąd usługi rozpoznawania mowy: {e}")
            return ""
        except Exception as e:
            self.speak(f"Nieoczekiwany błąd podczas rozpoznawania: {e}")
            print(f"Nieoczekiwany błąd rozpoznawania: {e}")
            return ""


    def extract_python_code(self, text):
        """
        Ekstrahuje kod Pythona z bloku markdown (```python ... ```).
        Jeśli nie znajdzie bloku, zwraca cały tekst.
        """
        start_tag = "```python"
        end_tag = "```"
        
        start_index = text.find(start_tag)
        if start_index != -1:
            code_start = start_index + len(start_tag)
            code_end = text.find(end_tag, code_start)
            
            if code_end != -1:
                return text[code_start:code_end].strip()
        
        return text.strip()


    def execute_python_code(self, code_text):
        """
        Wykonuje kod Pythona w osobnym procesie i zwraca jego wyjście.
        OSTRZEŻENIE: Wykonywanie dowolnego kodu jest POTENCJALNIE NIEBEZPIECZNE.
        """
        if not code_text:
            return "Błąd: Brak kodu do wykonania."

        temp_file_name = "temp_generated_code.py"
        try:
            with open(temp_file_name, "w", encoding="utf-8") as f:
                f.write(code_text)
        except Exception as e:
            return f"Błąd zapisu kodu do pliku: {e}"

        try:
            result = subprocess.run(
                [sys.executable, temp_file_name],
                capture_output=True,
                text=True,
                check=True,
                encoding='utf-8'
            )
            output = f"Wykonano kod. Wynik:\n{result.stdout}"
            if result.stderr:
                output += f"\nBłędy (stderr):\n{result.stderr}"
            return output
        except subprocess.CalledProcessError as e:
            return (f"Błąd podczas wykonywania kodu:\n"
                    f"Kod wyjścia: {e.returncode}\n"
                    f"Standardowy wyjście (stdout):\n{e.stdout}\n"
                    f"Błędy (stderr):\n{e.stderr}")
        except FileNotFoundError:
            return "Błąd: Nie znaleziono interpretera Pythona. Upewnij się, że Python jest w PATH."
        except Exception as e:
            return f"Nieoczekiwany błąd podczas wykonywania kodu: {e}"
        finally:
            if os.path.exists(temp_file_name):
                os.remove(temp_file_name)


    def process_command(self, command):
        response = "Nie rozumiem komendy. Proszę spróbować ponownie lub wpisać 'pomoc'."

        # Nowa komenda do ładowania pytań quizowych
        if "załadować pytania quizu" in command or "wczytaj pytania quizu" in command:
            self.speak("Próbuję załadować pytania quizu z pliku...")
            if self.game_manager.load_quiz_questions():
                response = "Pytania quizu zostały pomyślnie załadowane."
            else:
                response = "Nie udało się załadować pytań quizu. Sprawdź, czy plik quiz_questions.json istnieje i jest poprawny."
            return response

        # --- OBSŁUGA TRYBU TWORZENIA GRY ---
        if self.game_manager.game_creation_mode_active:
            if "zgadnij liczbę" in command:
                self.game_manager.guess_number_game_active = True
                self.game_manager.secret_number = random.randint(1, 100)
                self.game_manager.guess_attempts = 0
                self.game_manager.game_creation_mode_active = False
                response = f"Stworzyłem grę 'Zgadnij liczbę'! Pomyślałem o liczbie od 1 do 100. Wpisz swoją pierwszą próbę."
                return response
            elif "anuluj" in command:
                self.game_manager.game_creation_mode_active = False
                response = "Anulowano tworzenie gry."
                return response
            else:
                response = "Nie rozumiem. Jaki typ gry chcesz stworzyć? (np. 'Zgadnij liczbę')"
                return response

        # --- OBSŁUGA AKTYWNEJ GRY 'ZGADNIJ LICZBĘ' ---
        if self.game_manager.guess_number_game_active:
            try:
                guess = int(command)
                self.game_manager.guess_attempts += 1
                if guess == self.game_manager.secret_number:
                    response = f"Brawo! Zgadłeś liczbę {self.game_manager.secret_number} w {self.game_manager.guess_attempts} próbach. Koniec gry."
                    self.game_manager.reset_guess_number_game()
                elif guess < self.game_manager.secret_number:
                    response = "Za mało. Spróbuj wyżej."
                else:
                    response = "Za dużo. Spróbuj niżej."
            except ValueError:
                response = "To nie jest liczba. Podaj liczbę całkowitą."
            return response
        
        # --- OBSŁUGA AKTYWNEGO QUIZU ---
        if self.game_manager.quiz_active:
            if command == "koniec quizu" or command == "stop quiz":
                response = f"Koniec quizu. Twój wynik to {self.game_manager.quiz_score} na {len(self.game_manager.quiz_questions)}."
                self.game_manager.reset_quiz_game()
                return response
            
            if self.game_manager.quiz_question_index < len(self.game_manager.quiz_questions):
                current_question = self.game_manager.quiz_questions[self.game_manager.quiz_question_index]
                if command.lower() == current_question["answer"].lower():
                    response = "Poprawna odpowiedź!"
                    self.game_manager.quiz_score += 1
                    self.game_manager.quiz_question_index += 1
                    if self.game_manager.quiz_question_index < len(self.game_manager.quiz_questions):
                        response += f" Następne pytanie: {self.game_manager.quiz_questions[self.game_manager.quiz_question_index]['question']}"
                    else:
                        response += f" Koniec quizu! Odpowiedziałeś na wszystkie pytania poprawnie. Twój wynik: {self.game_manager.quiz_score} na {len(self.game_manager.quiz_questions)}."
                        self.game_manager.reset_quiz_game()
                elif "podpowiedź" in command.lower() and "hint" in current_question:
                    response = f"Podpowiedź: {current_question['hint']}"
                else:
                    response = "Niepoprawna odpowiedź. Spróbuj ponownie."
            else:
                response = f"Quiz zakończony. Twój wynik to {self.game_manager.quiz_score} na {len(self.game_manager.quiz_questions)}. Aby zagrać ponownie, wpisz 'zagraj w quiz'."
                self.game_manager.reset_quiz_game()
            return response


        # --- ISTNIEJĄCE KOMENDY (TERAZ PO POLSKU) ---
        if "otwórz" in command:
            if "stronę" in command or "strone" in command or "witrynę" in command or "wytryne" in command:
                parts = command.split("stronę ")
                if len(parts) > 1:
                    url = parts[1].strip().split(" ")[0]
                    response = f"Otwieram {url}"
                    open_website(url)
                else:
                    response = "Jaką stronę mam otworzyć?"
            elif "program" in command or "aplikację" in command or "aplikacje" in command:
                parts = command.split("program ")
                if len(parts) > 1:
                    program_name = parts[1].strip()
                    response = open_program(program_name)
                    if "Nie udało się otworzyć" in response:
                        response = f"Nie udało się otworzyć programu {program_name}."
                else:
                    response = "Jaki program mam otworzyć?"
        elif "szukaj w wikipedii" in command or "znajdź w wikipedii" in command:
            query = command.replace("szukaj w wikipedii", "").replace("znajdź w wikipedii", "").strip()
            if query:
                response = search_wikipedia(query)
                if "Nie mogę znaleźć informacji" in response:
                    response = f"Nie mogę znaleźć informacji o {query} w Wikipedii."
                elif "jest niejednoznacznym" in response:
                    response = f"Zapytanie '{query}' jest niejednoznaczne. Proszę sprecyzować."
            else:
                response = "Czego szukać w Wikipedii?"
        elif "napisz" in command or "wpisz" in command:
            text_to_type = command.replace("napisz", "").replace("wpisz", "").strip()
            if text_to_type:
                response = f"Wpisuję tekst: '{text_to_type}'"
                type_text(text_to_type)
            else:
                response = "Co mam napisać?"
        elif "naciśnij" in command:
            key_name = command.replace("naciśnij", "").strip()
            if key_name:
                response = f"Naciskam klawisz: {key_name}"
                press_key(key_name)
            else:
                response = "Jaki klawisz mam nacisnąć?"
        elif "klawisze skrótu" in command or "skrót klawiszowy" in command:
            if "ctrl c" in command or "control c" in command:
                response = "Naciskam Ctrl + C."
                send_hotkey('ctrl', 'c')
            elif "ctrl v" in command or "control v" in command:
                response = "Naciskam Ctrl + V."
                send_hotkey('ctrl', 'v')
            elif "alt f4" in command:
                response = "Naciskam Alt + F4."
                send_hotkey('alt', 'f4')
            else:
                response = "Nie rozumiem tej kombinacji klawiszy."
        elif "wyłącz komputer" in command:
            response = "Wyłączam komputer. Do zobaczenia!"
            self.speak(response)
            shutdown_computer()
            sys.exit()
        elif "uruchom ponownie komputer" in command or "restartuj komputer" in command:
            response = "Ponownie uruchamiam komputer."
            self.speak(response)
            restart_computer()
            sys.exit()
        elif "cześć bot" in command or "witaj bot" in command:
            response = "Cześć! Czym mogę pomóc?"
        elif "jak się masz" in command or "co u ciebie" in command:
            response = "U mnie wszystko dobrze, dziękuję. A u Ciebie?"
        elif "do widzenia" in command or "stop" in command:
            response = "Do zobaczenia! Mam nadzieję, że wkrótce się spotkamy."
            self.speak(response)
            root_window.quit()
            sys.exit()
        elif "zaktualizuj się" in command or "sprawdź aktualizacje" in command:
            self.speak("Sprawdzam dostępność aktualizacji.")
            if check_for_updates():
                self.speak("Dostępne są nowe aktualizacje. Chcesz zainstalować? Wpisz 'tak' lub 'nie'.")
                confirm = self.get_gui_input_blocking()
                if "tak" in confirm:
                    if download_and_install_update():
                        self.speak("Aktualizacja zakończona pomyślnie. Ponownie uruchamiam bota.")
                        restart_bot()
                    else:
                        self.speak("Nie udało się zainstalować aktualizacji. Sprawdź logi.")
                else:
                    self.speak("Dobrze, aktualizacja odłożona.")
            else:
                self.speak("Masz już najnowszą wersję bota.")

        # Komendy związane z grami
        elif "gra" in command:
            if "skocz" in command or "skocz do góry" in command:
                response = simulate_game_action("skok")
            elif "idź do przodu" in command or "idź naprzód" in command:
                response = simulate_game_action("do przodu")
            elif "strzel" in command:
                response = simulate_game_action("strzel")
            elif "przeładuj" in command:
                response = simulate_game_action("przeładuj")
            else:
                response = "Nie rozumiem tej komendy do gry."
            return response

        elif "stwórz grę" in command:
            self.game_manager.game_creation_mode_active = True
            response = "Wchodzę w tryb tworzenia gry. Jaki typ gry chcesz stworzyć? (np. 'Zgadnij liczbę', 'Quiz')"
            return response
        
        elif "zagraj w quiz" in command:
            if not self.game_manager.quiz_questions:
                response = "Nie mam żadnych pytań do quizu. Spróbuj najpierw 'załadować pytania quizu'."
                return response

            self.game_manager.quiz_active = True
            self.game_manager.quiz_question_index = 0
            self.game_manager.quiz_score = 0
            response = f"Zaczynam quiz! Aby zakończyć, wpisz 'koniec quizu'. "
            response += f"Pierwsze pytanie: {self.game_manager.quiz_questions[self.game_manager.quiz_question_index]['question']}"
            return response

        # Nowe komendy systemowe
        elif "utwórz folder" in command:
            parts = command.split("utwórz folder ")
            if len(parts) > 1:
                folder_name = parts[1].strip()
                response = create_folder(folder_name)
            else:
                response = "Jak nazwać nowy folder?"
        elif "usuń folder" in command:
            parts = command.split("usuń folder ")
            if len(parts) > 1:
                folder_name = parts[1].strip()
                response = delete_folder(folder_name)
            else:
                response = "Jaki folder mam usunąć?"
        elif "otwórz folder" in command:
            parts = command.split("otwórz folder ")
            if len(parts) > 1:
                folder_type = parts[1].strip()
                response = open_special_folder(folder_type)
            else:
                response = "Jaki folder mam otworzyć? (np. pulpit, dokumenty, pobrane)"
        elif "sprawdź dysk" in command or "ile miejsca na dysku" in command:
            response = get_disk_space()
        
        # Nowa komenda do obliczeń
        elif "oblicz" in command or "ile to jest" in command:
            expression = command.replace("oblicz", "").replace("ile to jest", "").strip()
            if expression:
                response = calculate_expression(expression)
            else:
                response = "Co mam obliczyć?"

        # Nowa komenda do tłumaczenia
        elif "przetłumacz na" in command:
            parts = command.split("przetłumacz na ")
            if len(parts) > 1:
                target_and_text = parts[1].strip()
                first_space = target_and_text.find(" ")
                if first_space != -1:
                    target_language = target_and_text[:first_space].strip()
                    text_to_translate = target_and_text[first_space:].strip()
                    if text_to_translate:
                        self.speak(f"Tłumaczę na {target_language}...")
                        response = translate_text_with_gemini(text_to_translate, target_language)
                    else:
                        response = "Co mam przetłumaczyć?"
                else:
                    response = "Nie rozumiem, na jaki język i co mam przetłumaczyć. Spróbuj: 'przetłumacz na angielski cześć świecie'."
            else:
                response = "Co mam przetłumaczyć i na jaki język?"

        elif "co potrafisz" in command or "pomoc" in command:
            response = "Potrafię otwierać strony internetowe, uruchamiać programy, wyszukiwać w Wikipedii, wpisywać tekst, naciskać klawisze, używać klawiszy skrótu, a także wyłączać i restartować komputer. Mogę też sprawdzić aktualizacje oraz tworzyć i grać w proste gry tekstowe, takie jak 'Zgadnij liczbę' czy 'Quiz'. Mogę również odpowiadać na Twoje pytania, korzystając ze sztucznej inteligencji, oraz wykonywać proste obliczenia, tłumaczyć tekst, tworzyć i usuwać foldery, a także otwierać specjalne foldery systemowe i sprawdzać miejsce na dysku. Mogę również generować pomysły na nowe komendy i nawet pisać dla Ciebie kod!"
        
        # Nowa komenda do integracji z Gemini (ogólne zapytania)
        elif "zapytaj inteligencję" in command or "powiedz mi o" in command or "wyjaśnij co to" in command:
            self.speak("Proszę czekać, pytam sztuczną inteligencję...")
            if "zapytaj inteligencję" in command:
                prompt_for_gemini = command.replace("zapytaj inteligencję", "").strip()
            elif "powiedz mi o" in command:
                prompt_for_gemini = command.replace("powiedz mi o", "Opowiedz mi o").strip()
            elif "wyjaśnij co to" in command:
                prompt_for_gemini = command.replace("wyjaśnij co to", "Wyjaśnij co to jest").strip()
            else:
                prompt_for_gemini = command

            if prompt_for_gemini:
                gemini_response = get_gemini_response(prompt_for_gemini)
                response = gemini_response
            else:
                response = "Co mam zapytać sztuczną inteligencję?"
        
        # --- NOWA KOMENDA DO GENEROWANIA POMYSŁÓW NA KOMENDY (SAMOROZWÓJ) ---
        elif "zaproponuj nową komendę" in command or "pomysły na komendy" in command:
            self.speak("Proszę czekać, pytam sztuczną inteligencję o nowe pomysły na komendy...")
            current_capabilities = "otwieranie stron, programów, pisanie tekstu, naciskanie klawiszy, wyszukiwanie w Wikipedii, wyłączanie/restartowanie komputera, sprawdzanie aktualizacji, tworzenie/granie w gry tekstowe (Zgadnij liczbę, Quiz), wykonywanie obliczeń, tłumaczenie tekstu, tworzenie/usuwanie folderów, otwieranie specjalnych folderów, sprawdzanie miejsca na dysku, odpowiadanie na pytania ogólne."
            prompt = f"Zaproponuj 3-5 nowych, użytecznych komend dla bota sterującego komputerem, który potrafi już: {current_capabilities}. Komendy powinny być krótkie i praktyczne. Podaj tylko nazwy komend i krótkie opisy, bez kodu."
            gemini_response = get_gemini_response(prompt)
            response = f"Oto kilka pomysłów na nowe komendy:\n{gemini_response}"
        # --- KONIEC NOWEJ KOMENDY ---

        # --- NOWA KOMENDA DO GENEROWANIA KODU ---
        elif "napisz kod na" in command or "wygeneruj kod na" in command:
            self.speak("Proszę czekać, generuję kod...")
            prompt_for_code = command.replace("napisz kod na", "").replace("wygeneruj kod na", "").strip()
            if prompt_for_code:
                gemini_code_response = get_gemini_response(f"Napisz kod Pythona, który {prompt_for_code}. Podaj tylko kod, bez dodatkowych wyjaśnień, w bloku kodu.")
                self.last_generated_code = gemini_code_response
                response = f"Wygenerowałem kod. Proszę sprawdzić konsolę. Możesz powiedzieć 'uruchom kod', aby go wykonać. \n{gemini_code_response}"
                self.speak(f"Wygenerowałem kod. Proszę sprawdzić konsolę. Możesz powiedzieć 'uruchom kod', aby go wykonać.")
            else:
                response = "Co mam zakodować?"
        # --- KONIEC NOWEJ KOMENDY ---

        # --- NOWA KOMENDA DO WYKONYWANIA KODU ---
        elif "uruchom kod" in command:
            if self.last_generated_code:
                self.speak("UWAGA: Wykonywanie dowolnego kodu jest potencjalnie niebezpieczne. Upewnij się, że rozumiesz, co robisz. Wykonuję kod...")
                print("\n" + "="*50)
                print("WYKONYWANIE WYGENEROWANEGO KODU:")
                print("="*50 + "\n")
                
                code_to_execute = self.extract_python_code(self.last_generated_code)
                execution_result = self.execute_python_code(code_to_execute)
                
                print("\n" + "="*50)
                print("KONIEC WYKONYWANIA KODU")
                print("="*50 + "\n")
                
                response = f"Wynik wykonania kodu: {execution_result}"
                self.speak("Wykonano kod. Wynik został wyświetlony w konsoli.")
            else:
                response = "Nie mam żadnego kodu do uruchomienia. Najpierw powiedz 'napisz kod na...'."
        # --- KONIEC NOWEJ KOMENDY ---

        # --- NOWA KOMENDA DO ASYSTOWANEGO PROGRAMOWANIA (GENEROWANIE CAŁEGO PLIKU Z WALIDACJĄ) ---
        elif "zaprogramuj funkcję" in command or "dodaj nową funkcję" in command:
            self.speak("Rozumiem. Proszę podać opis funkcji, którą mam zaprogramować, oraz do którego pliku ma zostać dodana (main.py lub bot_commands.py).")
            self.speak("Na przykład: 'zaprogramuj funkcję do wysyłania maili do pliku bot_commands.py'")
            
            programming_request = self.get_gui_input_blocking()
            
            if "do pliku" not in programming_request:
                response = "Nie rozumiem formatu. Proszę podać opis i nazwę pliku docelowego."
                return response

            parts = programming_request.split("do pliku")
            function_description = parts[0].strip()
            target_file_name = parts[1].strip().lower().replace(".py", "") + ".py"

            if target_file_name not in ["main.py", "bot_commands.py"]:
                response = "Nieprawidłowa nazwa pliku docelowego. Musi być 'main.py' lub 'bot_commands.py'."
                return response

            self.speak(f"Generuję kod dla funkcji '{function_description}' do pliku {target_file_name}. Proszę czekać...")

            try:
                with open(os.path.join(os.getcwd(), target_file_name), "r", encoding="utf-8") as f:
                    original_file_content = f.read()
            except FileNotFoundError:
                response = f"Błąd: Nie znaleziono pliku {target_file_name}."
                return response
            except Exception as e:
                response = f"Błąd podczas wczytywania pliku {target_file_name}: {e}"
                return response

            prompt_for_full_file = (
                f"Jesteś asystentem programisty. Twoim zadaniem jest zmodyfikowanie istniejącego pliku Pythona. "
                f"Dodaj nową funkcję, która {function_description}. "
                f"Zintegruj tę funkcję w odpowiednim miejscu w pliku (jeśli to funkcja pomocnicza, umieść ją w `bot_commands.py`; "
                f"jeśli to nowa komenda dla użytkownika, umieść jej obsługę w `main.py`). "
                f"Dodaj niezbędne importy na górze pliku. "
                f"**Na początku zmodyfikowanego pliku, w komentarzu, podaj listę wszystkich nowych bibliotek, które trzeba zainstalować za pomocą `pip install` (np. # Potrzebne biblioteki: pip install nazwa_biblioteki).** "
                f"Zwróć CAŁĄ, ZMODYFIKOWANĄ zawartość pliku `{target_file_name}`. "
                f"Oto obecna zawartość pliku `{target_file_name}`:\n\n```python\n{original_file_content}\n```\n\n"
                f"Zwróć tylko pełny kod Pythona dla zmodyfikowanego pliku, bez dodatkowych wyjaśnień."
            )

            gemini_response_full_file = get_gemini_response(prompt_for_full_file)

            if gemini_response_full_file:
                cleaned_code = self.extract_python_code(gemini_response_full_file)
                
                self.speak("Wygenerowałem kod. Sprawdzam jego poprawność...")
                validation_result = self.execute_python_code(cleaned_code)
                
                if "Błąd podczas wykonywania kodu" in validation_result or "Błąd zapisu kodu" in validation_result:
                    response = (
                        f"Wygenerowany kod zawiera błędy i nie może zostać bezpiecznie zintegrowany. "
                        f"Szczegóły błędu (w konsoli, gdzie uruchomiono bota): \n{validation_result}"
                        f"\nProszę spróbować ponownie z innym opisem funkcji lub zgłosić problem."
                    )
                    self.speak("Wygenerowany kod zawiera błędy. Nie mogę go bezpiecznie zintegrować.")
                    print(f"\n--- BŁĄD WALIDACJI KODU ---\n{validation_result}\n--- KONIEC BŁĘDU WALIDACJI ---")
                else:
                    response = (
                        f"Wygenerowałem nową wersję pliku {target_file_name} z dodaną funkcją. "
                        f"Kod przeszedł wstępną walidację. "
                        f"Proszę, skopiuj całą poniższą zawartość i wklej ją do pliku {target_file_name}, zastępując starą. "
                        f"Następnie uruchom bota ponownie. "
                        f"\n\n```python\n{cleaned_code}\n```"
                    )
                    self.speak(f"Wygenerowałem nową wersję pliku {target_file_name}. Kod przeszedł wstępną walidację. Proszę sprawdzić konsolę i zaktualizować plik ręcznie.")
                    print(f"\n--- WYNIK WALIDACJI KODU ---\n{validation_result}\n--- KONIEC WYNIKU WALIDACJI ---")

            else:
                response = "Nie udało mi się wygenerować zmodyfikowanego pliku. Spróbuj ponownie z innym opisem."
        # --- KONIEC NOWEJ KOMENDY DO ASYSTOWANEGO PROGRAMOWANIA ---

        # --- NOWA KOMENDA DO ARCHIWIZACJI DANYCH ---
        elif "archiwizuj folder" in command:
            self.speak("Rozumiem. Proszę podać ścieżkę do folderu do archiwizacji i nazwę pliku archiwum.")
            self.speak("Na przykład: 'archiwizuj folder C:\\MojeDane jako MojeArchiwum'")
            
            archive_request = self.get_gui_input_blocking()
            
            if "jako" not in archive_request:
                response = "Nie rozumiem formatu. Proszę użyć formatu: 'archiwizuj folder [ścieżka] jako [nazwa_archiwum]'."
                return response
            
            parts = archive_request.split("jako")
            folder_part = parts[0].replace("archiwizuj folder", "").strip()
            archive_name_part = parts[1].strip()

            if not folder_part or not archive_name_part:
                response = "Błąd: Brak ścieżki folderu lub nazwy archiwum."
                return response

            source_folder = folder_part.strip('"').strip("'")
            output_archive_name = archive_name_part.strip('"').strip("'")

            self.speak(f"Rozpoczynam archiwizację folderu '{source_folder}' do pliku '{output_archive_name}.zip'. Proszę czekać...")
            
            archive_result = archive_folder(source_folder, output_archive_name)
            response = archive_result
            self.speak("Archiwizacja zakończona.")

        # --- KONIEC NOWEJ KOMENDY DO ARCHIWIZACJI DANYCH ---

        else:
            response = "Przepraszam, nie rozumiem, co wpisałeś. Spróbuj jeszcze raz."

        return response

# --- GŁÓWNE ZMIENNE GLOBALNE GUI (DO KTÓRYCH ODWOLUJE SIE handle_input_from_gui i activate_voice_command) ---
# Używamy zmiennej do przechowywania wprowadzonej komendy
gui_command_queue = []
gui_command_event = threading.Event() # Sygnalizuje, kiedy komenda jest dostępna

root_window = None
output_text_widget = None
input_entry_widget = None
bot_assistant = None # Globalna instancja BotAssistant

def handle_input_from_gui():
    """Pobiera tekst z pola Entry GUI i dodaje do kolejki."""
    user_input = input_entry_widget.get()
    input_entry_widget.delete(0, tk.END) # Wyczyść pole wprowadzania
    
    if output_text_widget:
        output_text_widget.config(state='normal')
        output_text_widget.insert(tk.END, f"Ty: {user_input}\n")
        output_text_widget.see(tk.END)
        output_text_widget.config(state='disabled')
        root_window.update_idletasks()

    gui_command_queue.append(user_input.lower())
    gui_command_event.set() # Ustaw zdarzenie, aby zasygnalizować dostępność komendy

def activate_voice_command():
    """Aktywuje nasłuchiwanie komendy głosowej i przetwarza ją."""
    global bot_assistant
    if bot_assistant:
        voice_command = bot_assistant.listen_for_command()
        if voice_command:
            response = bot_assistant.process_command(voice_command)
            bot_assistant.speak(response)

# --- GŁÓWNA FUNKCJA URUCHAMIAJĄCA BOTA I GUI ---
def main_gui():
    global output_text_widget, input_entry_widget, root_window, bot_assistant

    root_window = tk.Tk()
    root_window.title("Mój Asystent Bot")
    root_window.geometry("600x500")

    output_text_widget = scrolledtext.ScrolledText(root_window, wrap=tk.WORD, state='disabled', font=('Arial', 10))
    output_text_widget.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

    input_frame = tk.Frame(root_window)
    input_frame.pack(padx=10, pady=5, fill=tk.X)

    input_entry_widget = tk.Entry(input_frame, font=('Arial', 10))
    input_entry_widget.pack(side=tk.LEFT, fill=tk.X, expand=True)
    input_entry_widget.bind("<Return>", lambda event=None: handle_input_from_gui())

    send_button = tk.Button(input_frame, text="Wyślij", command=handle_input_from_gui)
    send_button.pack(side=tk.RIGHT, padx=(5, 0))

    # DODAJ NOWĄ PRZYCISK DO AKTYWACJI ROZPOZNAWANIA GŁOSU
    mic_button = tk.Button(input_frame, text="Mów", command=lambda: threading.Thread(target=activate_voice_command).start())
    mic_button.pack(side=tk.RIGHT, padx=(5, 0))

    output_text_widget.config(state='normal')
    output_text_widget.insert(tk.END, "Bot: Ładowanie...\n")
    output_text_widget.config(state='disabled')
    root_window.update_idletasks()

    # Utwórz instancję BotAssistant po inicjalizacji GUI
    bot_assistant = BotAssistant(output_text_widget, gui_command_queue, gui_command_event)

    bot_thread = threading.Thread(target=run_bot_logic)
    bot_thread.daemon = True
    bot_thread.start()

    root_window.mainloop()

def run_bot_logic():
    """Główna pętla logiki bota, działająca w osobnym wątku."""
    global bot_assistant

    initial_message = "Cześć! Bot jest aktywny. Wpisz 'cześć bot', aby rozpocząć."
    bot_assistant.speak(initial_message)

    # Spróbuj załadować pytania quizu przy starcie
    if bot_assistant.game_manager.load_quiz_questions():
        bot_assistant.speak("Pytania quizu załadowane.")
    else:
        bot_assistant.speak("Nie udało się załadować pytań quizu przy starcie. Możesz spróbować komendy 'załadować pytania quizu'.")


    while True:
        command = bot_assistant.get_gui_input_blocking()
        if command:
            if "cześć bot" in command or "witaj bot" in command:
                bot_assistant.speak(f"Cześć! Czym mogę pomóc?")
                while True:
                    command = bot_assistant.get_gui_input_blocking()
                    if command:
                        if "do widzenia" in command or "stop" in command:
                            bot_assistant.speak("Do zobaczenia!")
                            root_window.quit()
                            sys.exit()
                        response = bot_assistant.process_command(command)
                        bot_assistant.speak(response)
            elif "do widzenia" in command or "stop" in command:
                bot_assistant.speak("Do zobaczenia!")
                root_window.quit()
                sys.exit()
        time.sleep(0.1)

if __name__ == "__main__":
    main_gui()