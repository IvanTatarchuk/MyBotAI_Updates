import requests
import os
import zipfile
import shutil
import sys
import subprocess
import hashlib

# URL, gdzie będzie leżał plik z ostatnią wersją oraz archiwum oprogramowania
# PAMIĘTAJ, ABY ZASTĄPIĆ TO SWOIMI PRAWDZIWYMI URL-ami Z GITHUB LUB INNEGO HOSTA!
LATEST_VERSION_URL = "https://raw.githubusercontent.com/TwojaNazwa/MojBotAI/main/latest_version.txt" # ZMIEŃ TO NA SWÓJ LINK!
UPDATE_ZIP_URL = "https://raw.githubusercontent.com/TwojaNazwa/MojBotAI/main/update.zip" # ZMIEŃ TO NA SWÓJ LINK!

def get_current_version():
    """Reads the current version from version.txt file."""
    try:
        with open("version.txt", "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "0.0.0" # Initial version, using a more standard format

def get_latest_version_and_hash():
    """Pobiera ostatnią wersję i sumę kontrolną z zdalnego serwera."""
    try:
        response = requests.get(LATEST_VERSION_URL)
        response.raise_for_status() # Check for HTTP errors
        content = response.text.strip().split(':')
        if len(content) == 2:
            return content[0], content[1] # version, hash
        print("Błąd: Nieprawidłowy format pliku latest_version.txt. Oczekiwano 'wersja:hash'.")
        return None, None
    except requests.exceptions.RequestException as e:
        print(f"Błąd podczas pobierania najnowszej wersji i hasha: {e}")
        return None, None

def calculate_md5(filepath, chunk_size=8192):
    """Oblicza sumę kontrolną MD5 dla pliku."""
    md5 = hashlib.md5()
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(chunk_size), b''):
            md5.update(chunk)
    return md5.hexdigest()

def download_and_install_update():
    """Downloads and installs the update."""
    print("Rozpoczynam pobieranie aktualizacji...")
    latest_version, expected_hash = get_latest_version_and_hash()
    if not latest_version or not expected_hash:
        print("Nie udało się pobrać informacji o najnowszej wersji lub hasha. Nie mogę kontynuować aktualizacji.")
        return False

    update_zip_path = "update.zip"
    temp_update_dir = os.path.join(os.getcwd(), "temp_update")
    backup_dir = os.path.join(os.getcwd(), "backup_pre_update")

    try:
        response = requests.get(UPDATE_ZIP_URL, stream=True)
        response.raise_for_status()

        with open(update_zip_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print("Aktualizacja pobrana.")

        # Verify checksum
        actual_hash = calculate_md5(update_zip_path)
        if actual_hash != expected_hash:
            print(f"BŁĄD: Niezgodność sumy kontrolnej dla update.zip! Oczekiwano: {expected_hash}, Otrzymano: {actual_hash}")
            os.remove(update_zip_path) # Usuwamy uszkodzony plik
            return False
        print("Suma kontrolna pomyślnie zweryfikowana.")

        # Backup current files before updating
        print("Tworzę kopię zapasową bieżącej wersji...")
        if os.path.exists(backup_dir):
            shutil.rmtree(backup_dir)
        os.makedirs(backup_dir)

        # Kopiujemy tylko pliki i foldery, które mogą zostać nadpisane lub zmienione
        for item in os.listdir(os.getcwd()):
            # Wyklucz foldery i pliki tymczasowe, które nie powinny być kopiowane
            if item not in ["venv", "backup_pre_update", "update.zip", "__pycache__", ".git", ".idea", "temp_update"]:
                s = os.path.join(os.getcwd(), item)
                d = os.path.join(backup_dir, item)
                if os.path.isdir(s):
                    # shutil.copytree wymaga, aby katalog docelowy nie istniał
                    # Jeśli Python < 3.8, trzeba ręcznie usuwać 'd' przed kopiowaniem, jeśli istnieje
                    # Dla 3.8+ możemy użyć dirs_exist_ok=True
                    shutil.copytree(s, d, dirs_exist_ok=True) 
                else:
                    shutil.copy2(s, d)
        print("Kopia zapasowa utworzona pomyślnie.")

        # Unpack the update
        if os.path.exists(temp_update_dir):
            shutil.rmtree(temp_update_dir)
        os.makedirs(temp_update_dir)

        with zipfile.ZipFile(update_zip_path, 'r') as zip_ref:
            zip_ref.extractall(temp_update_dir)
        print("Aktualizacja rozpakowana.")

        # Copy updated files to current directory
        # W tym miejscu instalujemy aktualizację
        for item in os.listdir(temp_update_dir):
            s = os.path.join(temp_update_dir, item)
            d = os.path.join(os.getcwd(), item)
            if os.path.isdir(s):
                if os.path.exists(d):
                    shutil.rmtree(d)
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)

        print("Aktualizacja zainstalowana.")

        # Update version file
        with open("version.txt", "w") as f:
            f.write(latest_version)
        print(f"Wersja zaktualizowana do {latest_version}")

        # Clean up temporary files
        os.remove(update_zip_path)
        shutil.rmtree(temp_update_dir)
        # shutil.rmtree(backup_dir) # Opcjonalnie: usuń backup po udanej aktualizacji

        return True

    except Exception as e:
        print(f"Błąd podczas instalacji aktualizacji: {e}")
        # Rollback in case of error
        print("Próbuję przywrócić do poprzedniej wersji...")
        try:
            if os.path.exists(backup_dir):
                for item in os.listdir(backup_dir):
                    s = os.path.join(backup_dir, item)
                    d = os.path.join(os.getcwd(), item)
                    if os.path.isdir(s):
                        if os.path.exists(d):
                            shutil.rmtree(d)
                        shutil.copytree(s, d)
                    else:
                        shutil.copy2(s, d)
                print("Przywracanie zakończone pomyślnie.")
            else:
                print("Brak katalogu kopii zapasowej do przywrócenia.")
        except Exception as rollback_e:
            print(f"BŁĄD: Nie udało się przywrócić! Może być wymagana ręczna interwencja. Błąd: {rollback_e}")
        finally:
            # Upewniamy się, że pliki tymczasowe są zawsze usuwane
            if os.path.exists(update_zip_path):
                os.remove(update_zip_path)
            if os.path.exists(temp_update_dir):
                shutil.rmtree(temp_update_dir)
            # backup_dir zostawiamy, aby użytkownik mógł sprawdzić, jeśli rollback się nie udał.
        return False

def check_for_updates():
    """Checks for updates and offers to install."""
    current_version_str = get_current_version()
    latest_version_str, _ = get_latest_version_and_hash()

    print(f"Obecna wersja bota: {current_version_str}")

    if latest_version_str:
        current_v_parts = list(map(int, current_version_str.split('.')))
        latest_v_parts = list(map(int, latest_version_str.split('.')))

        if latest_v_parts > current_v_parts:
            print(f"Dostępna nowa wersja: {latest_version_str}. Obecna: {current_version_str}")
            return True
        else:
            print("Masz już najnowszą wersję bota.")
    else:
        print("Nie udało się sprawdzić aktualizacji (nie można pobrać informacji o najnowszej wersji).")
    return False

def restart_bot():
    """Restarts the bot."""
    print("Restartuję bota...")
    python = sys.executable
    os.execl(python, python, *sys.argv)