def dodawanie(x, y):
  return x + y

def odejmowanie(x, y):
  return x - y

def mnozenie(x, y):
  return x * y

def dzielenie(x, y):
  if y == 0:
    return "Nie można dzielić przez zero!"
  else:
    return x / y

while True:
  print("\nWybierz operację:")
  print("1. Dodawanie")
  print("2. Odejmowanie")
  print("3. Mnożenie")
  print("4. Dzielenie")
  print("5. Wyjście")

  wybor = input("Wybierz opcję (1/2/3/4/5): ")

  if wybor in ('1', '2', '3', '4'):
    try:
      num1 = float(input("Podaj pierwszą liczbę: "))
      num2 = float(input("Podaj drugą liczbę: "))
    except ValueError:
      print("Błędne dane. Wprowadź liczbę.")
      continue

    if wybor == '1':
      print(num1, "+", num2, "=", dodawanie(num1, num2))

    elif wybor == '2':
      print(num1, "-", num2, "=", odejmowanie(num1, num2))

    elif wybor == '3':
      print(num1, "*", num2, "=", mnozenie(num1, num2))

    elif wybor == '4':
      print(num1, "/", num2, "=", dzielenie(num1, num2))

  elif wybor == '5':
    print("Koniec programu.")
    break

  else:
    print("Nieprawidłowy wybór. Spróbuj ponownie.")